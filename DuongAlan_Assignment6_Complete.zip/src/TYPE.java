/*
 * Programmer: Alan Duong
 */
public enum TYPE {
	COFFEE, SMOOTHIE, ALCOHOL
}