/*
 * Programmer: Alan Duong
 */
public enum SIZE {
	SMALL, MEDIUM, LARGE
}
